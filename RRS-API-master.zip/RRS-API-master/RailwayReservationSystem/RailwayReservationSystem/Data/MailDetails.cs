﻿namespace RailwayReservationSystem.Data
{
    public class MailDetails
    {
        public string To { get; set; }
        public string Subject { get; set; }
    }
}
